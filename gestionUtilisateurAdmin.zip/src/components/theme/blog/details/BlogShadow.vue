<template>
    <div class="col-xl-6 set-col-12 box-col-12">
        <div class="card">
            <div class="blog-box blog-shadow"><img class="img-fluid" src="@/assets/images/blog/blog.jpg" alt="">
                <div class="blog-details">
                    <p>25 July 2024</p>
                    <h5 class="text-white">People just don't do it anymore. We have to change that. Sometimes the simplest
                        things are the most profound.</h5>
                    <ul class="blog-social">
                        <li><i class="icofont icofont-user"></i>Mark Jecno</li>
                        <li><i class="icofont icofont-thumbs-up"></i>02 Hits</li>
                        <li><i class="icofont icofont-ui-chat"></i>598 Comments</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>