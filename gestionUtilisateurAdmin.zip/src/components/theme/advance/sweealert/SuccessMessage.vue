<template>
    <Card3 colClass="col-xxl-3 col-lg-4 col-sm-6 col-12" cardheaderClass=" height-equal" cardbodyClass=" btn-showcase"
        pre="true" preClass="f-m-light mt-1" headerTitle="true" title="Success Message" :desc="desc">
        <button class="btn btn-success sweet-8" type="button" @click="successAlert()">Login successfully</button>
    </Card3>
</template>
<script lang="ts" setup>
import Swal from 'sweetalert2'
import { defineAsyncComponent, ref } from 'vue'
const Card3 = defineAsyncComponent(() => import("@/components/common/card/CardData3.vue"))
let desc = ref<string>("Print the success message.")
function successAlert() {
    Swal.fire({
        icon: "success",
        title: "Good job!",
        text: "You clicked the button!",
        confirmButtonColor: 'var(--theme-default)',
    });
}
</script>