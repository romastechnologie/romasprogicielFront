<template>
    <a class="nav-link" target="_blank" href="https://support.pixelstrap.com/" data-original-title="">
        <div><img src="@/assets/images/customizer/support.png" alt="support"></div><span>Support</span>
    </a>
</template>