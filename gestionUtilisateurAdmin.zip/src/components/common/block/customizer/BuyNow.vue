<template>
    <a class="nav-link" target="_blank" href="https://themeforest.net/user/pixelstrap/portfolio" data-original-title="">
        <div><img src="@/assets/images/customizer/document.png" alt="document"></div><span>Buy now</span>
    </a>
</template>