<template>
    <a class="nav-link" target="_blank" href="https://docs.pixelstrap.net/vue/mofi/document/" data-original-title="">
        <div><img src="@/assets/images/customizer/setting.png" alt="setting"></div><span>Document</span>
    </a>
</template>