<template>
    <a class="nav-link" target="_blank" href="https://landing.pixelstrap.net/vue/mofi/template/" data-original-title="">
        <div><img src="@/assets/images/customizer/features.png" alt="features"></div><span>Check features</span>
    </a>
</template>