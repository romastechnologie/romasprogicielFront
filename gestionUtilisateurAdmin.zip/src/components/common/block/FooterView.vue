<template>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 footer-copyright d-flex flex-wrap align-items-center justify-content-between">
                    <p class="mb-0 f-w-600">Copyright 2024 © Romas Technologie </p>
                    <p class="mb-0 f-w-600">RProgiciel
                        <svg class="footer-icon">
                            <use href="@/assets/svg/icon-sprite.svg#footer-heart"> </use>
                        </svg>
                    </p>
                </div>
            </div>
        </div>
    </footer>
</template>