<template>
    <span class="header-search">
        <svg>
            <use href="@/assets/svg/icon-sprite.svg#search"></use>
        </svg>
    </span>
</template>